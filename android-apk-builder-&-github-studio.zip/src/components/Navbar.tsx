import React, { useState } from "react";
import {
  Smartphone,
  Play,
  Github,
  Wrench,
  UploadCloud,
  Sparkles,
  RefreshCw,
  History,
  Sun,
  Moon,
  Menu,
  X,
  FolderTree,
  ExternalLink,
  Zap,
} from "lucide-react";
import { AndroidProject, ValidationReport } from "../types";

interface NavbarProps {
  project: AndroidProject;
  validationReport: ValidationReport;
  githubConfig: { owner: string; repo: string; autoSync: boolean; token?: string };
  onOpenUpload: () => void;
  onOpenBugFixer: () => void;
  onOpenGitHub: () => void;
  onOpenHistory: () => void;
  onStartBuild: () => void;
  onToggleAiChat: () => void;
  onNewProject: () => void;
  onSelectTemplate: (templateId: string) => void;
  onToggleAutoSync?: () => void;
  isRepairing: boolean;
  lastSavedAt?: string | null;
  ideTheme: "dark" | "light";
  onToggleIdeTheme: () => void;
  onToggleMobileFiles?: () => void;
  isMobileFilesOpen?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  project,
  validationReport,
  githubConfig,
  onOpenUpload,
  onOpenBugFixer,
  onOpenGitHub,
  onOpenHistory,
  onStartBuild,
  onToggleAiChat,
  onNewProject,
  onSelectTemplate,
  onToggleAutoSync,
  isRepairing,
  lastSavedAt,
  ideTheme,
  onToggleIdeTheme,
  onToggleMobileFiles,
  isMobileFilesOpen,
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const issueCount = validationReport.issues.length + validationReport.missingFiles.length;
  const isGithubConnected = Boolean(githubConfig.token && githubConfig.repo);
  const ownerName = githubConfig.owner || "rehmanmobilez786";
  const repoName = githubConfig.repo || "android-apk-builder-studio";
  const repoUrl = `https://github.com/${ownerName}/${repoName}`;

  return (
    <header
      className={`border-b px-3 sm:px-4 py-2 flex flex-col md:flex-row md:items-center justify-between shadow-md transition-colors relative z-30 ${
        ideTheme === "light"
          ? "bg-white border-slate-200 text-slate-800"
          : "bg-slate-900 border-slate-800 text-white"
      }`}
    >
      {/* Top Main Row */}
      <div className="flex items-center justify-between w-full md:w-auto gap-2">
        <div className="flex items-center gap-2">
          {/* Mobile File Tree Drawer Toggle Button */}
          {onToggleMobileFiles && (
            <button
              onClick={onToggleMobileFiles}
              className={`md:hidden p-1.5 rounded-lg border text-xs flex items-center gap-1 ${
                isMobileFilesOpen
                  ? "bg-sky-500/20 text-sky-400 border-sky-500/50"
                  : ideTheme === "light"
                  ? "bg-slate-100 text-slate-700 border-slate-300"
                  : "bg-slate-800 text-slate-300 border-slate-700"
              }`}
              title="Toggle Files Drawer"
            >
              <FolderTree className="w-4 h-4" />
            </button>
          )}

          {/* Brand Logo */}
          <div className="flex items-center gap-1.5 sm:gap-2.5 bg-gradient-to-r from-sky-500 via-indigo-500 to-purple-600 px-2.5 py-1 sm:py-1.5 rounded-lg shadow-sm shrink-0">
            <Smartphone className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
            <div className="flex flex-col">
              <span className="font-extrabold text-xs sm:text-sm tracking-wide text-white leading-tight">
                Google AI Studio
              </span>
              <span className="text-[8px] sm:text-[9px] uppercase font-bold text-sky-200 leading-none">
                APK Builder Studio
              </span>
            </div>
          </div>

          {/* GitHub Linked Repo Direct Badge & Link */}
          <div className="hidden lg:flex items-center gap-1.5 bg-slate-950/80 border border-slate-800 px-2.5 py-1 rounded-lg text-xs">
            <a
              href={repoUrl}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1.5 text-purple-300 hover:text-purple-200 font-mono text-[11px] transition-colors"
              title="Open GitHub Repository (پروجیکٹ ریپو کھولیں)"
            >
              <Github className="w-3.5 h-3.5 text-purple-400 shrink-0" />
              <span className="font-semibold">{ownerName}/{repoName}</span>
              <ExternalLink className="w-3 h-3 text-slate-500" />
            </a>

            {/* Auto-Update Sync Toggle Button */}
            {onToggleAutoSync && (
              <button
                onClick={onToggleAutoSync}
                className={`ml-1 flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full border transition-all ${
                  githubConfig.autoSync
                    ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
                    : "bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200"
                }`}
                title={
                  githubConfig.autoSync
                    ? "Auto-Update ON: کوئی بھی تبدیلی خودکار گٹ ہب پر اپڈیٹ ہو گی"
                    : "Auto-Update OFF: کلک کر کے آٹو اپڈیٹ آن کریں"
                }
              >
                <span
                  className={`w-1.5 h-1.5 rounded-full ${
                    githubConfig.autoSync ? "bg-emerald-400 animate-pulse" : "bg-slate-500"
                  }`}
                />
                <span>{githubConfig.autoSync ? "Auto-Update ON" : "Auto-Update OFF"}</span>
              </button>
            )}
          </div>
        </div>

        {/* Mobile Header Actions (Build APK & Mobile Menu Button) */}
        <div className="flex items-center gap-1.5 md:hidden">
          <button
            onClick={onStartBuild}
            className="flex items-center gap-1 bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-bold text-xs px-3 py-1.5 rounded-lg shadow-md active:scale-95"
          >
            <Play className="w-3.5 h-3.5 fill-slate-950" />
            <span>BUILD</span>
          </button>

          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className={`p-1.5 rounded-lg border text-slate-300 ${
              ideTheme === "light"
                ? "bg-slate-100 border-slate-300 text-slate-700"
                : "bg-slate-800 border-slate-700"
            }`}
          >
            {isMobileMenuOpen ? <X className="w-5 h-5 text-rose-400" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Desktop Navigation Items */}
      <div className="hidden md:flex items-center gap-2 overflow-x-auto py-0.5">
        {/* Template Selector for medium screens */}
        <select
          value={project.id}
          onChange={(e) => onSelectTemplate(e.target.value)}
          className={`text-xs font-medium px-2.5 py-1.5 rounded-md border outline-none cursor-pointer transition-colors ${
            ideTheme === "light"
              ? "bg-slate-100 text-slate-800 border-slate-300 hover:bg-slate-200"
              : "bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-750"
          }`}
        >
          <option value="proj-google-ai-studio">✨ Google AI Studio</option>
          <option value="proj-ecommerce">🛍️ ShopSphere</option>
          <option value="proj-broken-demo">⚠️ Bug Recovery</option>
        </select>

        {/* IDE Day / Night Theme Toggle */}
        <button
          onClick={onToggleIdeTheme}
          className={`flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-md border transition-colors ${
            ideTheme === "light"
              ? "bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200"
              : "bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700"
          }`}
          title={ideTheme === "light" ? "Switch to Night Mode" : "Switch to Day Mode"}
        >
          {ideTheme === "light" ? (
            <Sun className="w-4 h-4 text-amber-500" />
          ) : (
            <Moon className="w-4 h-4 text-purple-400" />
          )}
          <span className="hidden lg:inline">{ideTheme === "light" ? "Day" : "Night"}</span>
        </button>

        {/* Session Protection & History Button */}
        <button
          onClick={onOpenHistory}
          className={`flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-md border transition-colors shadow-sm relative ${
            ideTheme === "light"
              ? "bg-slate-100 border-slate-300 text-slate-800 hover:bg-slate-200"
              : "bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700"
          }`}
          title="History & Session Protection"
        >
          <History className="w-4 h-4 text-sky-400" />
          <span className="hidden lg:inline">History</span>
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
        </button>

        {/* Drag and Drop File Upload Trigger */}
        <button
          onClick={onOpenUpload}
          className={`flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-md border transition-colors shadow-sm ${
            ideTheme === "light"
              ? "bg-slate-100 border-slate-300 text-slate-800 hover:bg-slate-200"
              : "bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700"
          }`}
          title="Drag & Drop Zip"
        >
          <UploadCloud className="w-4 h-4 text-sky-400" />
          <span className="hidden xl:inline">Upload Zip</span>
        </button>

        {/* AI Bug Fixer */}
        <button
          onClick={onOpenBugFixer}
          disabled={isRepairing}
          className={`relative flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-md border font-medium transition-all shadow-sm ${
            issueCount > 0
              ? "bg-amber-950/60 border-amber-500/50 text-amber-200 hover:bg-amber-900/80"
              : ideTheme === "light"
              ? "bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200"
              : "bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750"
          }`}
        >
          {isRepairing ? (
            <RefreshCw className="w-4 h-4 text-amber-400 animate-spin" />
          ) : (
            <Wrench className="w-4 h-4 text-amber-400" />
          )}
          <span>{isRepairing ? "Fixing..." : "Auto-Repair"}</span>
          {issueCount > 0 && (
            <span className="bg-amber-500 text-slate-950 font-bold text-[10px] px-1.5 py-0.2 rounded-full">
              {issueCount}
            </span>
          )}
        </button>

        {/* GitHub Integration Modal Trigger */}
        <button
          onClick={onOpenGitHub}
          className={`flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-md border font-medium transition-colors ${
            isGithubConnected
              ? "bg-purple-950/60 border-purple-500/50 text-purple-300 hover:bg-purple-900/80"
              : ideTheme === "light"
              ? "bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200"
              : "bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700"
          }`}
        >
          <Github className="w-4 h-4 text-purple-400" />
          <span className="hidden xl:inline">GitHub Sync</span>
        </button>

        {/* AI Assistant Chat Toggle */}
        <button
          onClick={onToggleAiChat}
          className="flex items-center gap-1.5 bg-indigo-900/60 hover:bg-indigo-800/80 text-indigo-200 text-xs px-2.5 py-1.5 rounded-md border border-indigo-700/60 transition-colors shadow-sm"
        >
          <Sparkles className="w-4 h-4 text-indigo-400" />
          <span>AI Architect</span>
        </button>

        {/* Primary Build APK Button */}
        <button
          onClick={onStartBuild}
          className="flex items-center gap-1.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs px-3.5 py-1.5 rounded-md shadow-md transition-all active:scale-95 shrink-0"
        >
          <Play className="w-4 h-4 fill-slate-950" />
          <span>BUILD APK</span>
        </button>
      </div>

      {/* Mobile Drawer Dropdown Menu */}
      {isMobileMenuOpen && (
        <div
          className={`md:hidden mt-2 pt-2 border-t flex flex-col gap-2 text-xs transition-colors ${
            ideTheme === "light" ? "border-slate-200 bg-slate-50" : "border-slate-800 bg-slate-900"
          }`}
        >
          {/* GitHub Repo link for mobile */}
          <div className="p-2 rounded-lg bg-slate-800/40 border border-slate-700/40 flex items-center justify-between">
            <a
              href={repoUrl}
              target="_blank"
              rel="noreferrer"
              className="text-purple-300 flex items-center gap-1 text-[11px] font-mono"
            >
              <Github className="w-3.5 h-3.5" />
              <span>{ownerName}/{repoName}</span>
              <ExternalLink className="w-3 h-3" />
            </a>

            {onToggleAutoSync && (
              <button
                onClick={onToggleAutoSync}
                className={`text-[9px] px-2 py-0.5 rounded-full font-bold border ${
                  githubConfig.autoSync
                    ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
                    : "bg-slate-800 text-slate-400 border-slate-700"
                }`}
              >
                {githubConfig.autoSync ? "Auto-Update: ON" : "Auto-Update: OFF"}
              </button>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              onClick={() => {
                onToggleIdeTheme();
                setIsMobileMenuOpen(false);
              }}
              className="flex items-center gap-2 p-2.5 rounded-lg border border-slate-700 bg-slate-800/40 text-slate-200"
            >
              {ideTheme === "light" ? (
                <Sun className="w-4 h-4 text-amber-400" />
              ) : (
                <Moon className="w-4 h-4 text-purple-400" />
              )}
              <span>{ideTheme === "light" ? "Day Theme" : "Night Theme"}</span>
            </button>

            <button
              onClick={() => {
                onOpenHistory();
                setIsMobileMenuOpen(false);
              }}
              className="flex items-center gap-2 p-2.5 rounded-lg border border-slate-700 bg-slate-800/40 text-slate-200"
            >
              <History className="w-4 h-4 text-sky-400" />
              <span>History & Saves</span>
            </button>

            <button
              onClick={() => {
                onOpenBugFixer();
                setIsMobileMenuOpen(false);
              }}
              className="flex items-center gap-2 p-2.5 rounded-lg border border-slate-700 bg-slate-800/40 text-slate-200"
            >
              <Wrench className="w-4 h-4 text-amber-400" />
              <span>Auto-Repair ({issueCount})</span>
            </button>

            <button
              onClick={() => {
                onOpenUpload();
                setIsMobileMenuOpen(false);
              }}
              className="flex items-center gap-2 p-2.5 rounded-lg border border-slate-700 bg-slate-800/40 text-slate-200"
            >
              <UploadCloud className="w-4 h-4 text-sky-400" />
              <span>Upload Source Zip</span>
            </button>

            <button
              onClick={() => {
                onOpenGitHub();
                setIsMobileMenuOpen(false);
              }}
              className="flex items-center gap-2 p-2.5 rounded-lg border border-slate-700 bg-slate-800/40 text-slate-200"
            >
              <Github className="w-4 h-4 text-purple-400" />
              <span>GitHub Sync</span>
            </button>

            <button
              onClick={() => {
                onToggleAiChat();
                setIsMobileMenuOpen(false);
              }}
              className="flex items-center gap-2 p-2.5 rounded-lg border border-indigo-700 bg-indigo-900/40 text-indigo-200"
            >
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <span>AI Architect</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
