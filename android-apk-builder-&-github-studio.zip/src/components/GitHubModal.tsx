import React, { useState } from "react";
import {
  Github,
  CheckCircle,
  X,
  Send,
  Lock,
  Tag,
  ShieldCheck,
  AlertTriangle,
  Info,
  HelpCircle,
  Key,
  User,
  Users,
  ExternalLink,
} from "lucide-react";
import { GitHubConfig } from "../types";

interface GitHubModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: GitHubConfig;
  onUpdateConfig: (newConfig: GitHubConfig) => void;
  onSyncNow: () => void;
  onCreateRelease: (tagName: string, notes: string) => void;
  isSyncing: boolean;
  syncMessage: string | null;
}

export const GitHubModal: React.FC<GitHubModalProps> = ({
  isOpen,
  onClose,
  config,
  onUpdateConfig,
  onSyncNow,
  onCreateRelease,
  isSyncing,
  syncMessage,
}) => {
  const [tokenInput, setTokenInput] = useState(config.token || "");
  const [ownerInput, setOwnerInput] = useState(config.owner || "rehmanmobilez786");
  const [repoInput, setRepoInput] = useState(config.repo || "android-apk-builder-studio");
  const [branchInput, setBranchInput] = useState(config.branch || "main");
  const [autoSync, setAutoSync] = useState(config.autoSync || false);
  const [releaseTag, setReleaseTag] = useState("v1.0.0");
  const [releaseNotes, setReleaseNotes] = useState("Automated APK release from APK Builder Studio");
  const [activeTab, setActiveTab] = useState<"sync" | "safety">("sync");

  React.useEffect(() => {
    if (config.token) setTokenInput(config.token);
    if (config.owner) setOwnerInput(config.owner);
    if (config.repo) setRepoInput(config.repo);
    if (config.branch) setBranchInput(config.branch);
  }, [config]);

  if (!isOpen) return null;

  const handleSelectAccount = (accountName: string) => {
    setOwnerInput(accountName);
  };

  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateConfig({
      token: tokenInput.trim(),
      owner: ownerInput.trim(),
      repo: repoInput.trim(),
      branch: branchInput.trim(),
      autoSync,
    });
  };

  const handlePushNow = () => {
    onUpdateConfig({
      token: tokenInput.trim(),
      owner: ownerInput.trim(),
      repo: repoInput.trim(),
      branch: branchInput.trim(),
      autoSync,
    });
    setTimeout(() => {
      onSyncNow();
    }, 50);
  };

  const handleReleaseNow = () => {
    onUpdateConfig({
      token: tokenInput.trim(),
      owner: ownerInput.trim(),
      repo: repoInput.trim(),
      branch: branchInput.trim(),
      autoSync,
    });
    setTimeout(() => {
      onCreateRelease(releaseTag, releaseNotes);
    }, 50);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-xl overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-200 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-gradient-to-r from-slate-900 via-purple-950/30 to-slate-900 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-purple-500/10 text-purple-400 rounded-lg">
              <Github className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-slate-100 text-sm">GitHub Repository & Cloud APK Sync</h3>
                <span className="bg-emerald-500/20 text-emerald-400 text-[10px] px-2 py-0.5 rounded-full font-bold border border-emerald-500/30 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" /> Anti-Suspension Shield Active
                </span>
              </div>
              <p className="text-xs text-slate-400">محفوظ سورس کوڈ پش، آٹومیٹڈ APK بلڈ، اور پالیسی پروٹیکشن</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 px-6 bg-slate-950/60 text-xs shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab("sync")}
            className={`py-3 px-4 font-semibold border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === "sync"
                ? "border-purple-500 text-purple-400 bg-purple-500/5"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <Github className="w-4 h-4" />
            <span>Sync & Credentials (کنفیگریشن)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab("safety")}
            className={`py-3 px-4 font-semibold border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === "safety"
                ? "border-emerald-500 text-emerald-400 bg-emerald-500/5"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Account Safety & Policies (اکاؤنٹ سسپنشن سے بچاؤ)</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {activeTab === "sync" ? (
            <form onSubmit={handleSaveConfig} className="space-y-4">
              {/* Token Input with Security Notice */}
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1.5 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Key className="w-3.5 h-3.5 text-purple-400" />
                    <span>Personal Access Token (PAT)</span>
                  </span>
                  <a
                    href="https://github.com/settings/tokens?type=beta"
                    target="_blank"
                    rel="noreferrer"
                    className="text-[11px] text-sky-400 hover:underline flex items-center gap-1"
                  >
                    Fine-Grained PAT بنائیں (Recommended) →
                  </a>
                </label>
                <input
                  type="password"
                  placeholder="github_pat_xxxxxxxx یا ghp_xxxxxxxxxxxxxxxxxxxx"
                  value={tokenInput}
                  onChange={(e) => setTokenInput(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-200 text-xs px-3 py-2.5 rounded-xl focus:outline-none focus:border-purple-500 font-mono"
                />
                <p className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
                  <Lock className="w-3 h-3" />
                  ٹوکن صرف براؤزر کی لوکل میموری میں رہتا ہے اور ریپوزٹری فائلز میں کبھی شامل نہیں ہوتا۔
                </p>
              </div>

              {/* Account Switcher Bar */}
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-purple-400" />
                    <span>مربوط گٹ ہب اکاؤنٹس (GitHub Accounts)</span>
                  </span>
                  <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                    ایکٹیو: @{ownerInput || "rehmanmobilez786"}
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  {/* rehmanmobilez786 - New Account */}
                  <button
                    type="button"
                    onClick={() => handleSelectAccount("rehmanmobilez786")}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                      ownerInput === "rehmanmobilez786"
                        ? "bg-purple-600/30 text-purple-200 border-purple-500 shadow-sm"
                        : "bg-slate-900 text-slate-400 border-slate-700 hover:text-slate-200 hover:border-slate-600"
                    }`}
                  >
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                    <User className="w-3.5 h-3.5" />
                    <span>rehmanmobilez786</span>
                    <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.2 rounded font-bold">
                      نیا اکاؤنٹ
                    </span>
                  </button>

                  {/* safdarali789 - Secondary */}
                  <button
                    type="button"
                    onClick={() => handleSelectAccount("safdarali789")}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                      ownerInput === "safdarali789"
                        ? "bg-purple-600/30 text-purple-200 border-purple-500 shadow-sm"
                        : "bg-slate-900 text-slate-400 border-slate-700 hover:text-slate-200 hover:border-slate-600"
                    }`}
                  >
                    <User className="w-3.5 h-3.5" />
                    <span>safdarali789</span>
                  </button>

                  {/* Direct Link to active profile */}
                  {ownerInput && (
                    <a
                      href={`https://github.com/${ownerInput}`}
                      target="_blank"
                      rel="noreferrer"
                      className="ml-auto text-[11px] text-sky-400 hover:underline flex items-center gap-1"
                    >
                      <span>پروفائل دیکھیں</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>
              </div>

              {/* Owner & Repo Inputs */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">GitHub Username / Owner</label>
                  <input
                    type="text"
                    placeholder="e.g. rehmanmobilez786"
                    value={ownerInput}
                    onChange={(e) => setOwnerInput(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 text-xs px-3 py-2 rounded-xl focus:outline-none focus:border-purple-500 font-mono"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">Repository Name</label>
                  <input
                    type="text"
                    placeholder="e.g. android-apk-builder-studio"
                    value={repoInput}
                    onChange={(e) => setRepoInput(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 text-xs px-3 py-2 rounded-xl focus:outline-none focus:border-purple-500 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">Target Branch</label>
                  <input
                    type="text"
                    placeholder="main"
                    value={branchInput}
                    onChange={(e) => setBranchInput(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 text-xs px-3 py-2 rounded-xl focus:outline-none focus:border-purple-500 font-mono"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">Release Version Tag</label>
                  <input
                    type="text"
                    placeholder="v1.0.0"
                    value={releaseTag}
                    onChange={(e) => setReleaseTag(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 text-xs px-3 py-2 rounded-xl focus:outline-none focus:border-purple-500 font-mono"
                  />
                </div>
              </div>

              {/* Anti-Violation Protections Active Badge */}
              <div className="bg-slate-950 border border-emerald-500/30 rounded-xl p-3 text-xs text-slate-300 space-y-2">
                <div className="flex items-center gap-2 font-bold text-emerald-400">
                  <ShieldCheck className="w-4 h-4" />
                  <span>GitHub Anti-Violation & Anti-Spam Protections Enabled</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-slate-400">
                  <div className="flex items-center gap-1.5">
                    <span className="text-emerald-400 font-bold">✓</span> Atomic 1-Commit Push (No API spam)
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-emerald-400 font-bold">✓</span> Secret Shield (No leaked keys/PATs)
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-emerald-400 font-bold">✓</span> Actions Concurrency & Timeouts
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-emerald-400 font-bold">✓</span> Rate Limit Throttling (3s cooldown)
                  </div>
                </div>
              </div>

              {syncMessage && (
                <div className={`p-3 text-xs rounded-xl flex items-start gap-2 ${
                  syncMessage.includes("❌") || syncMessage.includes("⚠️")
                    ? "bg-amber-950/40 border border-amber-800/60 text-amber-200"
                    : "bg-purple-950/40 border border-purple-800/60 text-purple-200"
                }`}>
                  <Info className="w-4 h-4 shrink-0 mt-0.5 text-purple-400" />
                  <span className="leading-relaxed">{syncMessage}</span>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={handleReleaseNow}
                  className="flex items-center gap-1.5 text-xs text-slate-300 hover:text-white bg-slate-800 px-3 py-2 rounded-xl border border-slate-700 transition-colors"
                >
                  <Tag className="w-3.5 h-3.5 text-sky-400" />
                  <span>Publish Release</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="submit"
                    className="text-xs text-emerald-300 hover:text-emerald-200 bg-emerald-950/60 hover:bg-emerald-900/60 px-3 py-2 rounded-xl border border-emerald-700/60 transition-colors font-medium"
                  >
                    Save Config
                  </button>
                  <button
                    type="button"
                    onClick={handlePushNow}
                    disabled={isSyncing}
                    className="flex items-center gap-2 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-md transition-all active:scale-95 disabled:opacity-50"
                  >
                    {isSyncing ? (
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                    <span>{isSyncing ? "محفوظ پش ہو رہا ہے..." : "Push Safe Commit"}</span>
                  </button>
                </div>
              </div>
            </form>
          ) : (
            /* Account Safety & Violation Prevention Guide */
            <div className="space-y-4 text-xs">
              <div className="bg-emerald-950/30 border border-emerald-500/30 rounded-xl p-4 space-y-2">
                <h4 className="font-bold text-emerald-300 flex items-center gap-2 text-sm">
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                  <span>GitHub اکاؤنٹ سسپنشن سے بچاؤ کے ضروری اصول</span>
                </h4>
                <p className="text-slate-300 leading-relaxed">
                  گٹ ہب کے روبوٹس اور سیکیورٹی سسٹمز کچھ خاص حرکات پر اکاؤنٹ معطل (Suspend) کرتے ہیں۔ ہم نے اس پروجیکٹ میں درج ذیل 5 سخت سیکیورٹی فلٹرز شامل کیے ہیں تاکہ آپ کا اکاؤنٹ 100% محفوظ رہے:
                </p>
              </div>

              <div className="space-y-3">
                {/* Point 1 */}
                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
                  <div className="font-bold text-slate-200 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center text-[10px] font-bold">1</span>
                    <span>Secret Scanning Violation سے بچاؤ (No Leaked Keys)</span>
                  </div>
                  <p className="text-slate-400 text-[11px] leading-relaxed pl-7">
                    اگر کوڈ فائل میں کوئی اصلی API Key یا Personal Access Token پش ہو جائے، تو GitHub Secret Scanner فوراً ایکشن لیتا ہے۔ ہمارا سسٹم پش سے پہلے تمام فائلز کو اسکین کر کے ایسے سیکریٹس کو خودکار محفوظ پلیس ہولڈرز میں تبدیل کر دیتا ہے۔
                  </p>
                </div>

                {/* Point 2 */}
                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
                  <div className="font-bold text-slate-200 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center text-[10px] font-bold">2</span>
                    <span>API Spam & Rate-Limit Prevention (Atomic Commit)</span>
                  </div>
                  <p className="text-slate-400 text-[11px] leading-relaxed pl-7">
                    پرانے ٹولز ہر فائل کے لیے الگ الگ کمٹ پش کرتے تھے (15 سے 20 لگاتار کمٹس سیکنڈوں میں)، جسے گٹ ہب بوٹ سپیم سمجھتا تھا۔ اب ہمارا سسٹم Git Tree API کے ذریعے تمام فائلز کو صرف <strong>1 سنگل کلین کمٹ</strong> میں پش کرتا ہے۔
                  </p>
                </div>

                {/* Point 3 */}
                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
                  <div className="font-bold text-slate-200 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center text-[10px] font-bold">3</span>
                    <span>GitHub Actions Fair Use (No Resource Exhaustion)</span>
                  </div>
                  <p className="text-slate-400 text-[11px] leading-relaxed pl-7">
                    ہماری ورک فلو فائل میں <code className="bg-slate-900 text-sky-400 px-1 py-0.5 rounded">concurrency: cancel-in-progress</code> اور <code className="bg-slate-900 text-sky-400 px-1 py-0.5 rounded">timeout-minutes: 25</code> فعال ہے تاکہ کوئی رن وے جابز نہ بنیں اور ایکشنز کا کوٹہ ضائع نہ ہو۔
                  </p>
                </div>

                {/* Point 4 */}
                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
                  <div className="font-bold text-slate-200 flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center text-[10px] font-bold">4</span>
                    <span>Fine-Grained Scoped Token تجویز</span>
                  </div>
                  <p className="text-slate-400 text-[11px] leading-relaxed pl-7">
                    مکمل اکاؤنٹ کی پرمیشن والے Classic Token کے بجائے ہمیشہ <strong>Fine-grained Personal Access Token</strong> بنائیں اور اسے صرف متعلقہ ریپوزٹری (<code className="bg-slate-900 text-emerald-400 px-1 py-0.5 rounded">android-apk-builder-studio</code>) تک محدود رکھیں۔
                  </p>
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={() => setActiveTab("sync")}
                  className="bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs px-4 py-2 rounded-xl transition-all"
                >
                  کنفیگریشن پیج پر واپس جائیں →
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
