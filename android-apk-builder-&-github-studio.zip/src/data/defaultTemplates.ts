import { AndroidProject } from "../types";

export const GOOGLE_AI_STUDIO_STARTER: AndroidProject = {
  id: "proj-google-ai-studio",
  name: "Google AI Studio Assistant",
  packageName: "com.googleaistudio.assistant",
  versionName: "1.0.0",
  versionCode: 1,
  minSdk: 24,
  targetSdk: 34,
  compileSdk: 34,
  files: [
    {
      path: "metadata.json",
      content: JSON.stringify(
        {
          name: "Google AI Studio Assistant",
          description: "Full-featured Gemini-powered AI Assistant built in Google AI Studio and converted to Native Android APK with offline web bundle and camera support.",
          requestFramePermissions: ["camera", "microphone"],
          majorCapabilities: ["MAJOR_CAPABILITY_SERVER_SIDE_GEMINI_API"],
        },
        null,
        2
      ),
    },
    {
      path: "app/src/main/AndroidManifest.xml",
      content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.googleaistudio.assistant">

    <!-- Google AI Studio Permissions -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="Google AI Studio Assistant"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:usesCleartextTraffic="true"
        android:hardwareAccelerated="true"
        android:theme="@style/Theme.GoogleAIStudio">
        
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden"
            android:windowSoftInputMode="adjustResize"
            android:label="Google AI Studio Assistant"
            android:theme="@style/Theme.GoogleAIStudio">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>`,
    },
    {
      path: "app/src/main/java/com/googleaistudio/assistant/MainActivity.kt",
      content: `package com.googleaistudio.assistant

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.*
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat

/**
 * Google AI Studio Production Android Host.
 * Bridges Gemini AI TypeScript / React Web Applet with Native Android Runtime.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val data: Intent? = result.data
            val results: Array<Uri>? = when {
                data?.dataString != null -> arrayOf(Uri.parse(data.dataString))
                data?.clipData != null -> {
                    val count = data.clipData!!.itemCount
                    Array(count) { i -> data.clipData!!.getItemAt(i).uri }
                }
                else -> null
            }
            fileUploadCallback?.onReceiveValue(results)
        } else {
            fileUploadCallback?.onReceiveValue(null)
        }
        fileUploadCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        progressBar = findViewById(R.id.progressBar)

        setupAIStudioWebView()
        loadAIStudioBundle()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupAIStudioWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        settings.cacheMode = WebSettings.LOAD_DEFAULT

        webView.addJavascriptInterface(AIStudioAndroidBridge(this), "AIStudioAndroid")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                progressBar.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                progressBar.visibility = View.GONE
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.progress = newProgress
                if (newProgress == 100) progressBar.visibility = View.GONE
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.grant(request.resources)
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileUploadCallback?.onReceiveValue(null)
                fileUploadCallback = filePathCallback

                val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                filePickerLauncher.launch(intent)
                return true
            }
        }
    }

    private fun loadAIStudioBundle() {
        webView.loadUrl("file:///android_asset/dist/index.html")
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}

/**
 * Native JavaScript Interface for Google AI Studio applets
 */
class AIStudioAndroidBridge(private val activity: MainActivity) {

    @JavascriptInterface
    fun showToast(message: String) {
        activity.runOnUiThread {
            Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()
        }
    }

    @JavascriptInterface
    fun triggerHapticFeedback() {
        activity.runOnUiThread {
            activity.window.decorView.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
        }
    }

    @JavascriptInterface
    fun getPlatform(): String {
        return "Google AI Studio Android APK (SDK \${Build.VERSION.SDK_INT})"
    }
}`,
    },
    {
      path: "app/src/main/res/layout/activity_main.xml",
      content: `<?xml version="1.0" encoding="utf-8"?>
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="#090D16">

    <ProgressBar
        android:id="@+id/progressBar"
        style="?android:attr/progressBarStyleHorizontal"
        android:layout_width="match_parent"
        android:layout_height="4dp"
        android:layout_alignParentTop="true"
        android:indeterminate="false"
        android:max="100"
        android:progressTint="#38BDF8"
        android:visibility="gone" />

    <WebView
        android:id="@+id/webView"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:layout_below="@id/progressBar" />

</RelativeLayout>`,
    },
    {
      path: "app/src/main/assets/dist/index.html",
      content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>Google AI Studio Assistant</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body {
      background-color: #090D16;
      color: #F8FAFC;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      margin: 0;
      padding: 0;
      -webkit-tap-highlight-color: transparent;
    }
  </style>
</head>
<body class="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between">
  <!-- Top Navigation -->
  <header class="bg-slate-900/90 backdrop-blur border-b border-slate-800 p-4 sticky top-0 z-20 flex items-center justify-between">
    <div class="flex items-center gap-3">
      <div class="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center font-bold text-white shadow-lg shadow-sky-500/20">
        ✨
      </div>
      <div>
        <h1 class="font-bold text-sm text-white">Google AI Studio</h1>
        <p class="text-[10px] text-sky-400 font-medium">Gemini 1.5 Flash • Android APK</p>
      </div>
    </div>
    <span class="bg-emerald-500/20 text-emerald-400 text-[10px] px-2.5 py-1 rounded-full font-bold border border-emerald-500/30">
      Online
    </span>
  </header>

  <!-- Interactive AI Chat Container -->
  <main class="flex-1 p-4 overflow-y-auto space-y-3 max-w-lg mx-auto w-full" id="chatArea">
    <div class="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl">
      <div class="flex items-center gap-2 text-xs font-semibold text-sky-400 mb-1">
        <span>🤖</span> Gemini Assistant
      </div>
      <p class="text-xs text-slate-300 leading-relaxed">
        Hello! I am your Google AI Studio assistant running inside a native Android APK. How can I help you today?
      </p>
    </div>
  </main>

  <!-- Input Bar -->
  <div class="p-3 bg-slate-900 border-t border-slate-800 sticky bottom-0">
    <form id="promptForm" class="flex gap-2 max-w-lg mx-auto">
      <input
        type="text"
        id="promptInput"
        placeholder="Ask Gemini anything..."
        class="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-500"
      />
      <button
        type="submit"
        class="bg-sky-600 hover:bg-sky-500 active:scale-95 text-white font-bold px-4 py-2.5 rounded-xl text-xs shadow-md transition-all">
        Send
      </button>
    </form>
  </div>

  <script>
    const chatArea = document.getElementById('chatArea');
    const promptForm = document.getElementById('promptForm');
    const promptInput = document.getElementById('promptInput');

    promptForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const val = promptInput.value.trim();
      if (!val) return;

      // Add user message
      const userBubble = document.createElement('div');
      userBubble.className = 'bg-sky-600 text-white rounded-2xl rounded-tr-none p-3 max-w-[85%] ml-auto text-xs font-medium shadow-md';
      userBubble.innerText = val;
      chatArea.appendChild(userBubble);
      promptInput.value = '';

      if (window.AIStudioAndroid) {
        window.AIStudioAndroid.triggerHapticFeedback();
      }

      // Add AI response
      setTimeout(() => {
        const aiBubble = document.createElement('div');
        aiBubble.className = 'bg-slate-900 border border-slate-800 rounded-2xl rounded-tl-none p-3 max-w-[85%] text-xs text-slate-200 shadow-md';
        aiBubble.innerHTML = '<span class="font-bold text-sky-400 block mb-1">🤖 Gemini Response:</span> I received your prompt: "' + val + '". Running seamlessly on Android APK build with full hardware acceleration!';
        chatArea.appendChild(aiBubble);
        chatArea.scrollTop = chatArea.scrollHeight;
      }, 600);

      chatArea.scrollTop = chatArea.scrollHeight;
    });
  </script>
</body>
</html>`,
    },
    {
      path: "app/src/main/res/values/strings.xml",
      content: `<resources>
    <string name="app_name">Google AI Studio Assistant</string>
</resources>`,
    },
    {
      path: "app/src/main/res/values/colors.xml",
      content: `<resources>
    <color name="primary">#0284C7</color>
    <color name="primary_dark">#0369A1</color>
    <color name="accent">#38BDF8</color>
</resources>`,
    },
    {
      path: "app/src/main/res/values/styles.xml",
      content: `<resources>
    <style name="Theme.GoogleAIStudio" parent="Theme.MaterialComponents.DayNight.NoActionBar">
        <item name="colorPrimary">@color/primary</item>
        <item name="colorPrimaryDark">@color/primary_dark</item>
        <item name="colorAccent">@color/accent</item>
        <item name="android:statusBarColor">#090D16</item>
    </style>
</resources>`,
    },
    {
      path: "app/build.gradle",
      content: `plugins {
    id 'com.android.application'
    id 'org.jetbrains.kotlin.android'
}

android {
    namespace 'com.googleaistudio.assistant'
    compileSdk 34

    defaultConfig {
        applicationId "com.googleaistudio.assistant"
        minSdk 24
        targetSdk 34
        versionCode 1
        versionName "1.0.0"

        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = '1.8'
    }
}

dependencies {
    implementation 'androidx.core:core-ktx:1.12.0'
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.webkit:webkit:1.9.0'
    implementation 'androidx.activity:activity-ktx:1.8.2'
    implementation 'com.squareup.okhttp3:okhttp:4.12.0'
    implementation 'org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3'
}`,
    },
    {
      path: "build.gradle",
      content: `buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath 'com.android.tools.build:gradle:8.2.2'
        classpath 'org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.22'
    }
}

task clean(type: Delete) {
    delete rootProject.buildDir
}`,
    },
    {
      path: "settings.gradle",
      content: `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "GoogleAIStudioAssistant"
include ':app'`,
    },
    {
      path: "gradle/wrapper/gradle-wrapper.properties",
      content: `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.2-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists`,
    },
    {
      path: "gradle.properties",
      content: `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.enableJetifier=true
kotlin.code.style=official`,
    },
    {
      path: ".github/workflows/android-build-apk.yml",
      content: `name: Build Google AI Studio Android APK

on:
  push:
    branches: [ "main", "master" ]
    paths-ignore:
      - '**.md'
      - '.gitignore'
  workflow_dispatch:

# Prevents runaway parallel builds & resource exhaustion (GitHub Policy Compliant)
concurrency:
  group: \${{ github.workflow }}-\${{ github.ref }}
  cancel-in-progress: true

permissions:
  contents: write

jobs:
  build:
    name: Assemble Android APK with Gradle & SDK 34
    runs-on: ubuntu-latest
    timeout-minutes: 25

    steps:
      - name: Checkout Google AI Studio Android Project
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'
          cache: gradle

      - name: Setup Android SDK Build-Tools & Platforms
        uses: android-actions/setup-android@v3

      - name: Grant Execute Permission for Gradlew
        run: chmod +x gradlew || true

      - name: Build Debug Android APK (assembleDebug)
        run: |
          if [ -f "./gradlew" ]; then
            ./gradlew assembleDebug --no-daemon --stacktrace
          else
            gradle assembleDebug --no-daemon --stacktrace
          fi

      - name: Upload Android APK Artifact for Download
        uses: actions/upload-artifact@v4
        with:
          name: google-ai-studio-app-debug
          path: app/build/outputs/apk/debug/*.apk
          retention-days: 14`,
    },
  ],
  updatedAt: new Date().toISOString(),
};

export const STARTER_PROJECT = GOOGLE_AI_STUDIO_STARTER;

export const ECOMMERCE_PROJECT: AndroidProject = {
  id: "proj-ecommerce",
  name: "ShopSphere",
  packageName: "com.shopsphere.app",
  versionName: "2.1.0",
  versionCode: 3,
  minSdk: 26,
  targetSdk: 34,
  compileSdk: 34,
  files: [
    {
      path: "metadata.json",
      content: JSON.stringify({
        name: "ShopSphere Storefront",
        description: "Google AI Studio E-Commerce Storefront converted to Android APK.",
        requestFramePermissions: [],
        majorCapabilities: ["MAJOR_CAPABILITY_SERVER_SIDE_GEMINI_API"]
      }, null, 2)
    },
    {
      path: "app/src/main/AndroidManifest.xml",
      content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.shopsphere.app">

    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
    <uses-permission android:name="android.permission.VIBRATE"/>

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="ShopSphere"
        android:theme="@style/Theme.ShopSphere">

        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>
    </application>
</manifest>`,
    },
    {
      path: "app/src/main/java/com/shopsphere/app/MainActivity.kt",
      content: `package com.shopsphere.app

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

data class Product(val id: Int, val title: String, val price: Double, val badge: String)

class MainActivity : AppCompatActivity() {

    private val products = listOf(
        Product(1, "Wireless Noise-Canceling Headphones", 199.99, "Hot Deals"),
        Product(2, "Smart Watch Ultra Titanium", 349.50, "Bestseller"),
        Product(3, "Mechanical Gaming Keyboard RGB", 129.00, "New"),
        Product(4, "Pro Lens Smartphone Camera Kit", 89.95, "Sale")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val totalItemsTv: TextView = findViewById(R.id.tvCartCount)
        totalItemsTv.text = "Featured Products (\${products.size})"
    }
}`,
    },
    {
      path: "app/src/main/res/layout/activity_main.xml",
      content: `<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:background="#090D16"
    android:padding="16dp">

    <RelativeLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:paddingVertical="12dp">

        <TextView
            android:id="@+id/tvBrand"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="ShopSphere 🛍️"
            android:textColor="#38BDF8"
            android:textSize="24sp"
            android:textStyle="bold"/>

        <TextView
            android:id="@+id/tvCartCount"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_alignParentEnd="true"
            android:text="Cart (0)"
            android:textColor="#E2E8F0"
            android:textSize="14sp"
            android:background="#1E293B"
            android:paddingHorizontal="12dp"
            android:paddingVertical="6dp"/>
    </RelativeLayout>

    <EditText
        android:id="@+id/etSearch"
        android:layout_width="match_parent"
        android:layout_height="48dp"
        android:hint="Search products..."
        android:textColorHint="#64748B"
        android:textColor="#FFFFFF"
        android:background="#1E293B"
        android:paddingHorizontal="16dp"
        android:layout_marginVertical="12dp"/>

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:background="#1E293B"
        android:padding="16dp"
        android:orientation="vertical"
        android:layout_marginBottom="12dp">

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Wireless Headphones Pro"
            android:textColor="#FFFFFF"
            android:textStyle="bold"/>

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="$199.99"
            android:textColor="#34D399"
            android:textSize="16sp"/>
    </LinearLayout>
</LinearLayout>`,
    },
    {
      path: "app/build.gradle",
      content: `plugins {
    id 'com.android.application'
    id 'org.jetbrains.kotlin.android'
}
android {
    namespace 'com.shopsphere.app'
    compileSdk 34
    defaultConfig {
        applicationId "com.shopsphere.app"
        minSdk 26
        targetSdk 34
        versionCode 3
        versionName "2.1.0"
    }
}
dependencies {
    implementation 'androidx.core:core-ktx:1.12.0'
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
}`,
    },
    {
      path: "build.gradle",
      content: `buildscript {
    repositories { google(); mavenCentral() }
    dependencies { classpath 'com.android.tools.build:gradle:8.2.2' }
}`,
    },
    {
      path: "settings.gradle",
      content: `rootProject.name = "ShopSphere"\ninclude ':app'`,
    },
  ],
  updatedAt: new Date().toISOString(),
};

export const BROKEN_TEST_PROJECT: AndroidProject = {
  id: "proj-broken-demo",
  name: "BrokenAppDemo",
  packageName: "com.example.brokenapp",
  versionName: "1.0.0",
  versionCode: 1,
  minSdk: 21,
  targetSdk: 34,
  compileSdk: 34,
  files: [
    {
      path: "app/src/main/java/com/example/brokenapp/MainActivity.kt",
      content: `package com.example.brokenapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val badVariable = 
    }
}`,
    },
    {
      path: "app/src/main/res/layout/activity_main.xml",
      content: `<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical">

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="This is a broken layout file with missing unclosed bracket
</LinearLayout>`,
    },
  ],
  updatedAt: new Date().toISOString(),
};
